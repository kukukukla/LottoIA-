"""
Lotérias Inteligência - Core Package
Módulos estatísticos e matemáticos para análise de loterias.
"""

from .models import Concurso, LoteriaTipo, EstrategiaConfig, JogoGerado
from .main_engine import MotorPrincipal
from .motor_estatistico import MotorEstatistico
from .motor_matematico import MotorMatematico
from .motor_simulacoes import MotorSimulacoes
from .motor_estrategias import MotorEstrategias
from .motor_score import MotorScore
from .motor_desdobramentos import MotorDesdobramentos
from .motor_temporal import MotorTemporal
from .motor_ml import MotorML
from .motor_padroes import MotorPadroes
from .motor_comparativo import MotorComparativo
from .motor_genetico import MotorGenetico
from .motor_relatorios import MotorRelatorios
from .gerador_jogos import GeradorJogos

__version__ = "2.0.0"
__author__ = "Motor Estatístico de Loterias"

__all__ = [
    "Concurso", "LoteriaTipo", "EstrategiaConfig", "JogoGerado",
    "MotorPrincipal", "MotorEstatistico", "MotorMatematico",
    "MotorSimulacoes", "MotorEstrategias", "MotorScore",
    "MotorDesdobramentos", "MotorTemporal", "MotorML",
    "MotorPadroes", "MotorComparativo", "MotorGenetico",
    "MotorRelatorios", "GeradorJogos"
]
